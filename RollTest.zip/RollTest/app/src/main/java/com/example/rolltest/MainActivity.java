package com.example.rolltest;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Vibrator;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.ref.WeakReference;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements SensorEventListener{
    ImageView tvShow;
    int drawableResource;
    AnimationDrawable animationDrawable1;
    Handler handler;
    Runnable runnable;
    Sensor sensor;
    SensorManager sensorManager;
    Vibrator vibrator;
    SoundPool soundPool;
    private static final String TAG = "MainActivity";
    //记录摇动状态
    private boolean isShake = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvShow = findViewById(R.id.tv_show);

        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);

        //初始化SoundPool
        soundPool = new SoundPool(1, AudioManager.STREAM_SYSTEM, 5);
        soundPool.load(this, R.raw.roll, 1);
    }

    public void rollbt(View view) {
        /*tvShow.setImageResource(R.drawable.alpha_anim);
        animationDrawable1 = (AnimationDrawable) tvShow.getDrawable();
        animationDrawable1.start();*/

        //Toast.makeText(MainActivity.this, "短点击"+num, Toast.LENGTH_SHORT).show();
        soundPool.play(1, 1, 1, 0, 0, 1);
        roll();
        /*Drawable drawable = getBaseContext().getResources().getDrawable(drawableResource);
        tvShow.setImageDrawable(drawable);*/
    }

    @Override
    protected void onStart() {
        super.onStart();
        //获取 SensorManager 负责管理传感器
        sensorManager = ((SensorManager) getSystemService(SENSOR_SERVICE));
        if (sensorManager != null) {
            //获取加速度传感器
            sensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            if (sensor != null) {
                sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_UI);
            }
        }
    }
    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener( this,sensor,200);
    }

    @Override
    protected void onPause() {
        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
        }
        super.onPause();
    }


    @Override
    public void onSensorChanged(SensorEvent event) {
        int type = event.sensor.getType();

        if (type == Sensor.TYPE_ACCELEROMETER) {
            //获取三个方向值
            float[] values = event.values;
            float x = values[0];
            float y = values[1];
            float z = values[2];

            if ((Math.abs(x) > 17 || Math.abs(y) > 17 || Math
                    .abs(z) > 17) && !isShake) {
                isShake = false;
                long[] patten = {200, 400};
                vibrator.vibrate(patten, -1);
                //声音效果
                soundPool.play(1, 1, 1, 0, 0, 1);
                roll();
            }
        }
        /*float[] values = event.values;
        float x = values[0];
        float y = values[1];
        float z = values[2];

        if (Math.abs(x) > 20 | Math.abs(y) > 20 | Math.abs(z) > 20) {
            long[] patten = {200, 400};
            vibrator.vibrate(patten, -1);
            //声音效果
            soundPool.play(1, 1, 1, 1, 1, 1);
            roll();
        }*/
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    public void roll(){
        //动画效果
        tvShow.setImageResource(R.drawable.alpha_anim);
        animationDrawable1 = (AnimationDrawable) tvShow.getDrawable();
        animationDrawable1.start();

        //生成随机数1-6
        int num = (int)(Math.random()*6)+1;
       /* Toast.makeText(MainActivity.this, "短点击"+num, Toast.LENGTH_SHORT).show();*/
        switch (num){ //给随机数设置图片，1为1点，2为2点以此类推
            case 1: drawableResource = R.drawable.roll1; break;
            case 2: drawableResource = R.drawable.roll2; break;
            case 3: drawableResource = R.drawable.roll3; break;
            case 4: drawableResource = R.drawable.roll4; break;
            case 5: drawableResource = R.drawable.roll5; break;
            case 6: drawableResource = R.drawable.roll6; break;
            default:
                throw new IllegalStateException("Unexpected value: " + num);
        }

        handler = new Handler();
        handler.postDelayed(runnable = new Runnable() {
            @Override
            public void run() {
                Drawable drawable = getBaseContext().getResources().getDrawable(drawableResource);
                tvShow.setImageDrawable(drawable);
            }
        },1000);

    }

}
